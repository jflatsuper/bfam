@extends('layouts.admin.app')

@section('content')
    <div class="container-fluid">
        <div class="row">
            @livewire('admin-all-course-list')
        </div>
    </div>
@endsection
