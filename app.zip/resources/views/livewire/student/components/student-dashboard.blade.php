<div class="section3126">
    <div class="row">
        <div class="col-xl-6 col-lg-12 col-md-6">
            <div class="value_props">
                <div class="value_icon">
                    <i class='uil uil-file'></i>
                </div>
                <div class="value_content">
                    <h4>Registered courses</h4>
                    <p>You registered for {{$totalStudents}} course(s)</p>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-12 col-md-6">
            <div class="value_props">
                <div class="value_icon">
                    <i class='uil uil-history'></i>
                </div>
                <div class="value_content">
                    <h4>Total courses</h4>
                    <p>{{$totalCourses}} courses are active on this platform</p>
                </div>
            </div>
        </div>
    </div>
</div>
